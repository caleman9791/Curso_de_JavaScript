https://en.m.wikipedia.org/wiki/Microsoft_Speech_API

Microsoft Speech API
The Speech Application Programming Interface 
or SAPI is an API developed by Microsoft to 
allow the use of speech recognition and speech 
synthesis within Windows applications. To date, 
a number of versions of the API have been released, 
which have shipped either as part of a Speech SDK, 
or as part of the Windows OS itself. Applications 
that use SAPI include Microsoft Office, Microsoft 
Agent and Microsoft Speech Server.


NNNN    NN OOOOOO TTTTTTTT EEEEEEE
NN NN   NN OO  OO    TT    EE
NN  NN  NN OO  OO    TT    EEEEE
NN   NN NN OO  OO    TT    EE
NN    NNNN OOOOOO    TT    EEEEEEE

before you can run this file, add first

	[COM_DOT_NET]
	extension=php_com_dotnet.dll

at the end of your 'php.ini' file
 
 Xampp for Windows = (Drive Letter):\xampp\php\php.ini
 Wamp (Drive Letter):\wamp\bin\apache\apache(version)\bin\php.ini   ----(I'm not sure about this one because I'm using Xampp)
 
 For Installation:
	http://php.net/manual/en/com.installation.php
	
 If you get error(s), refer to this link:
	https://stackoverflow.com/questions/10678325/class-com-not-found/12050332
	
Using this code, you can embed text-to-speech which you can use in registration system, attendance system and the like.
